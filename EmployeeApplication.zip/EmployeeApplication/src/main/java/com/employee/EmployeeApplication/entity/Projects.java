package com.employee.EmployeeApplication.entity;

import jakarta.persistence.*;

@Entity
@Table(name="projectsTable")
public class Projects {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String name;
    private String Clientname;

    public Projects(String name, String clientname) {
        this.name = name;
        Clientname = clientname;
    }

    public Projects() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getClientname() {
        return Clientname;
    }

    public void setClientname(String clientname) {
        Clientname = clientname;
    }
}
